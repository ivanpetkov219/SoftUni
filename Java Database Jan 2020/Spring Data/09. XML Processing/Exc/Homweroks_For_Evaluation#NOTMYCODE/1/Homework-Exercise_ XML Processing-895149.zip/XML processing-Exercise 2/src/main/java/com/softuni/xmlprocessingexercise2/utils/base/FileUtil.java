package com.product.shop.utils.base;

import java.io.IOException;

public interface FileUtil {
    String readContent(String fileName) throws IOException;
}
