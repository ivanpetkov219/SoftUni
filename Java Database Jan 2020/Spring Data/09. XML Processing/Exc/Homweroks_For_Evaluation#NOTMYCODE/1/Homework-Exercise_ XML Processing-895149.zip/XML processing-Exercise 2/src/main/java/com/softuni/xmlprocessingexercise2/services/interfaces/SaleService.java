package com.softuni.xmlprocessingexercise2.services.interfaces;

import com.softuni.xmlprocessingexercise2.entities.Sale;

import java.util.List;

public interface SaleService {

    void seedSales();

    void exerciseSix();
}
