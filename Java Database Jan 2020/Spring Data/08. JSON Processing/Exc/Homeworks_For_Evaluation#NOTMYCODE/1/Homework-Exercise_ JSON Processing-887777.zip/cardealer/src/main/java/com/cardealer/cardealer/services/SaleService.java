package com.cardealer.cardealer.services;

public interface SaleService {

    void seedSales();
}
