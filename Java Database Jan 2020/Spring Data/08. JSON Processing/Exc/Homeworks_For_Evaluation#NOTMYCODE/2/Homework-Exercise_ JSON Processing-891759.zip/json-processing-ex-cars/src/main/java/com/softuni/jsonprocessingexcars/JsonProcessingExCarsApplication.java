package com.softuni.jsonprocessingexcars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonProcessingExCarsApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsonProcessingExCarsApplication.class, args);
    }

}
