package com.softuni.jsonprocessingex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonProcessingExApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsonProcessingExApplication.class, args);
    }

}
