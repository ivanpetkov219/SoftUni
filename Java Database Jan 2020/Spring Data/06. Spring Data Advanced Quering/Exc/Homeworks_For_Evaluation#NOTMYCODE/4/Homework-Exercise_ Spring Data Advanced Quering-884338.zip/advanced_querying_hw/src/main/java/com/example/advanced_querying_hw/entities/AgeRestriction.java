package com.example.advanced_querying_hw.entities;

public enum AgeRestriction {
    
    MINOR,
    TEEN,
    ADULT;
}
