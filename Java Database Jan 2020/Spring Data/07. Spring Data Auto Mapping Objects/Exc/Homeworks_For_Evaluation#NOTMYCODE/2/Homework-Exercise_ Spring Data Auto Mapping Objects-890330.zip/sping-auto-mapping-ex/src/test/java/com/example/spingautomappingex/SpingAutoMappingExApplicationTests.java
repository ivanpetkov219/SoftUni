package com.example.spingautomappingex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpingAutoMappingExApplicationTests {

    @Test
    void contextLoads() {
    }

}
