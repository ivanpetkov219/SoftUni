package com.example.sprintdataintroex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintDataIntroExApplicationTests {

    @Test
    void contextLoads() {
    }

}
