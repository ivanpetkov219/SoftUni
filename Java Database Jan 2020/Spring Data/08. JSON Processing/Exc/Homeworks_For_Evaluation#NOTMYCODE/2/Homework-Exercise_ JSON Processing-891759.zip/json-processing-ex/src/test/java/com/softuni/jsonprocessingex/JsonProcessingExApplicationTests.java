package com.softuni.jsonprocessingex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonProcessingExApplicationTests {

    @Test
    void contextLoads() {
    }

}
