package com.spring.project.spring.user_system.services;

import org.springframework.stereotype.Service;

@Service("pictureService")
public interface PictureService {
}
