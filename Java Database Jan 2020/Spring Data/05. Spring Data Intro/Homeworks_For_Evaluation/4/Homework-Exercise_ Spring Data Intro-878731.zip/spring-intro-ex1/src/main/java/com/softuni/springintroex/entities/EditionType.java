package com.softuni.springintroex.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD;
}
