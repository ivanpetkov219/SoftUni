package springdata.automapping.services;

public interface GameService {

}
