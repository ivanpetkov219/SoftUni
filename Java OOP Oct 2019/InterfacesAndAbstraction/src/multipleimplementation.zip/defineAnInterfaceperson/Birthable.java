package defineAnInterfaceperson;

public interface Birthable {
}
