package spring.map.spingautomapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpingautomappingApplicationTests {

    @Test
    void contextLoads() {
    }

}
