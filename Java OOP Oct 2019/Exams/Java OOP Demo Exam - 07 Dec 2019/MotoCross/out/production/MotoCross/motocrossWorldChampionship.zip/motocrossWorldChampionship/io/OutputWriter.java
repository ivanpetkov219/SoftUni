package motocrossWorldChampionship.io;

public interface OutputWriter {
    void writeLine(String text);
}
