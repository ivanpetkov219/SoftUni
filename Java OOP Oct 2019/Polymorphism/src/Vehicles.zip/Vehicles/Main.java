package Vehicles;

import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String[] carInfo = scanner.nextLine().split("\\s+");
        String[] truckInfo = scanner.nextLine().split("\\s+");

        Map<String, VehicleImpl> vehicleMap = new HashMap<>();

        Car car = new Car(Double.parseDouble(carInfo[1]), Double.parseDouble(carInfo[2]));
        Truck truck = new Truck(Double.parseDouble(truckInfo[1]), Double.parseDouble(truckInfo[2]));

        vehicleMap.put("Car", car);
        vehicleMap.put("Truck", truck);


        int n = Integer.parseInt(scanner.nextLine());

        while(n-- > 0){
            String[] tokens = scanner.nextLine().split("\\s+");

            String command = tokens[0];
            String vehicleType = tokens[1];

            if(command.equals("Drive")){
                double distance = Double.parseDouble(tokens[2]);

                vehicleMap.get(vehicleType).drive(distance);

            }else if (command.equals("Refuel")){
                double liters = Double.parseDouble(tokens[2]);

                vehicleMap.get(vehicleType).refuel(liters);
            }
        }

        printRemainingFuel(vehicleMap);

    }

    private static void printRemainingFuel(Map<String, VehicleImpl> vehicleMap) {

        for (Map.Entry<String, VehicleImpl> entry : vehicleMap.entrySet()) {
            System.out.println(String.format("%s: %.2f", entry.getValue().getClass().getSimpleName(), entry.getValue().getFuelQuantity()));
        }

    }
}
