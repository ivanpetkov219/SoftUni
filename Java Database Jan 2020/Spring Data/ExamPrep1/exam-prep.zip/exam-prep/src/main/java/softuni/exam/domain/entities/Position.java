package softuni.exam.domain.entities;

public enum  Position {
    GK, CD, RB, LB, CDM, CM, LM, RM, CAM, ST, CF, RW, LW
}
