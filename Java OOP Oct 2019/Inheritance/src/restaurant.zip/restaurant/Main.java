package restaurant;

import java.math.BigDecimal;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


       // Coffee coffee = new Coffee("Lungo", BigDecimal.valueOf(3.1), 80, 9 );
//
       // Salmon salmon = new Salmon("Siomgichka", BigDecimal.valueOf(300.1), 80);
//
       // Cake cake = new Cake("Tortaaa", BigDecimal.valueOf(30.1), 80, 200000);
//
//
       // System.out.println(String.format("%s---%.2f---%.2f----%.2f",
       //         coffee.getName(),
       //         coffee.getPrice(),
       //         coffee.getMilliliters(),
       //         coffee.getCaffeine()));
//
       // System.out.println(String.format("%s---%.2f---%.2f----",
       //         salmon.getName(),
       //         salmon.getPrice(),
       //         salmon.getGrams()));
//
       // System.out.println(String.format("%s---%.2f---%.2f----%.2f",
       //         cake.getName(),
       //         cake.getPrice(),
       //         cake.getGrams(),
       //         cake.getCalories()));
//
    }
}
