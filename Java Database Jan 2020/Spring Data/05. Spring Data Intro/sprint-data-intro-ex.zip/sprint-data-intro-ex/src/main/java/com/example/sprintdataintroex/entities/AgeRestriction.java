package com.example.sprintdataintroex.entities;


public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
