package com.spring.project.spring.user_system.services.impls;

import com.spring.project.spring.user_system.services.PictureService;
import org.springframework.stereotype.Service;

@Service
public class PictureServiceImpl implements PictureService {
}
