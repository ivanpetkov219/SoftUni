package Demo;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.Properties;
import java.util.Scanner;

public class MainDiablo {
    public static final String conectionString = "jdbc:mysql://localhost:3306/";
    public static final String databaseName = "minions_db";
    private static Connection connection;
    private static String query;
    private static PreparedStatement statement;
    private static BufferedReader reader;

    public static void main(String[] args) throws SQLException, IOException {
        Scanner s = new Scanner(System.in);
        reader = new BufferedReader(new InputStreamReader(System.in));
        Properties properties = new Properties();
        properties.setProperty("user", "root");
        properties.setProperty("password", "root");
        connection = DriverManager
                .getConnection(conectionString + databaseName, properties);
        //2 ex
        //getViliansNamewithCOuntOfMinions();
        //3 ex
       // getMinionsNamesEx();
        //4 ex
        //addMinionEx();
        //5
       // changeTownNameToUpperCase();
        //6
        //removeVillainById();

        // 9 ex
        //increaseAgeWhitStoredProcedure();


    }

    private static void removeVillainById() throws IOException, SQLException {
        System.out.println("Enter number: ");
        int removed_id = Integer.parseInt(reader.readLine());
        query = "select name from villains\n" +
                "where id = ?;";
        statement = connection.prepareStatement(query);
        statement.setInt(1,removed_id);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            System.out.printf("%s was deleted", resultSet.getString("name"));
        }
        query = "delete from minions_villains\n" +
                "where villain_id = ?;";
        statement = connection.prepareStatement(query);
        statement.setInt(1,removed_id);
        statement.executeUpdate();

    }

    private static void changeTownNameToUpperCase() throws IOException, SQLException {
        System.out.println("Enter country: ");
        String country = reader.readLine();
        query = "update  towns\n" +
                "set name = upper(name)\n" +
                "where country = ?;";
        statement = connection.prepareStatement(query);
        statement.setString(1,country);
        statement.executeUpdate();
        query = "select name from towns where country = ?";
        statement = connection.prepareStatement(query);
        statement.setString(1,country);
        ResultSet resultSet =  statement.executeQuery();
        int count = 0;
        while (resultSet.next()) {
            System.out.printf("%s, ", resultSet.getString("name"));
            ++count;
        }
        if (count > 0) {
            System.out.printf("%d town names were affected. ", count);
        }else {
            System.out.println("No town names were affected.");
        }

    }

    private static void increaseAgeWhitStoredProcedure() throws IOException, SQLException {
        System.out.println("Enter minion id: ");
        int minionId = Integer.parseInt(reader.readLine());
        query = "CALL usp_get_older(?)";


        CallableStatement callableStatement = connection.prepareCall(query);
        callableStatement.setInt(1,minionId);
        callableStatement.execute();

    }

    private static void addMinionEx() throws IOException, SQLException {
        System.out.println("Enter minion parameters: ");
        String[] minPar = reader.readLine().split("\\s+");
        String minionName = minPar[0];
        int minAge = Integer.parseInt(minPar[1]);
        String minCity = minPar[2];
        System.out.println("Enter villain name: ");
        String vilName = reader.readLine();

        if (!checkIfEntityExistByName(minCity, "towns")){
            insertEntityInTown(minCity);
            System.out.printf("Town %s was added to the database.\n", minCity);
        }
        if(!checkIfEntityExistByName(vilName, "villains")){
            insertEntityInVillains(vilName);
            System.out.printf("Villain %s was added to the database.\n", vilName);
        }
        insertEntityInMinions(minionName, minAge);
        System.out.printf("Successfully added %s to be minion of %s", minionName, vilName);
    }


    private static void insertEntityInMinions(String name, int age) throws SQLException {
        query = "INSERT INTO minions (name,  age) value(?,?)";
        statement = connection.prepareStatement(query);
        statement.setString(1, name);
        statement.setInt(2, age);
        statement.execute();
    }

    private static void insertEntityInVillains(String vilName) throws SQLException {
        query = "INSERT INTO villains (name, evilness_factor) value(?,?)";
        statement = connection.prepareStatement(query);
        statement.setString(1, vilName);
        statement.setString(2, "evil");
        statement.execute();
    }

    private static void insertEntityInTown(String towns) throws SQLException {
        query = "INSERT INTO towns (name, country) value(?,?)";
        statement = connection.prepareStatement(query);
        statement.setString(1, towns);
        statement.setString(2, "null");
        statement.execute();
    }

    private static boolean checkIfEntityExistByName(String name, String tableName) throws SQLException {
        query = "SELECT * FROM " + tableName +  " where name = ?";
        statement = connection.prepareStatement(query);
        statement.setString(1, name);
        ResultSet resultSet = statement.executeQuery();
        return resultSet.next();

    }

    private static void getMinionsNamesEx() throws IOException, SQLException {
        System.out.println("Enter villain id:");
        int villain_id = Integer.parseInt(reader.readLine());
        if (!checkIfEntityExist(villain_id, "villains")){
            System.out.printf("No villain with ID %d exists in the database.", villain_id);
            return;
        }

       System.out.printf("Villain: %s%n", getEntityNameById(villain_id, "villains"));
        getMinionsAgeByVillainId(villain_id);

    }

    private static void getMinionsAgeByVillainId(int villain_id) throws SQLException {
        query = "SELECT m.name, m.age from minions as\n" +
                "m join minions_villains mv on m.id = mv.minion_id\n" +
                "where mv.villain_id = ?";
        statement = connection.prepareStatement(query);
        statement.setInt(1,villain_id);
        ResultSet resultSet = statement.executeQuery();
        int count = 0;
        while (resultSet.next()){
            System.out.printf("%d. %s %d%n", ++count,
                    resultSet.getString(1), resultSet.getInt("age"));
        }

    }

    private static Object getEntityNameById(int entityid, String tableName) throws SQLException {
        query = "SELECT name FROM " + tableName + " WHERE id = ?";
        statement = connection.prepareStatement(query);
        statement.setInt(1,entityid);
        ResultSet resultSet = statement.executeQuery();
        return resultSet.next() ? resultSet.getString(1) : null;
    }

    private static boolean checkIfEntityExist(int villain_id, String villains) throws SQLException {
        query = "SELECT * FROM " + villains + " where id = ?";
        statement = connection.prepareStatement(query);
        statement.setInt(1, villain_id);
        ResultSet resultSet = statement.executeQuery();
        return resultSet.next();

    }

    private static void getViliansNamewithCOuntOfMinions() throws SQLException {
        query = "SELECT v.name, COUNT(mv.minion_id) as 'count'\n" +
                "from villains as v join minions_villains mv on v.id = mv.villain_id\n" +
                "group by v.name\n" +
                "having `count` > 15\n" +
                "order by `count` desc";
        statement = connection.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            System.out.printf("%-15.15s %d%n", resultSet.getString("name"),
                    resultSet.getInt(2));
        }

    }

}
