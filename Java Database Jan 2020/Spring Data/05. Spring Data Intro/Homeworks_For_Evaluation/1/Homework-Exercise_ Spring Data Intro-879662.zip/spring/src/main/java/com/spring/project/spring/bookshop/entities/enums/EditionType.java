package com.spring.project.spring.bookshop.entities.enums;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
