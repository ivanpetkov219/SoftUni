package com.softuni.xmlparsingexerciseone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlParsingExerciseOneApplicationTests {

    @Test
    void contextLoads() {
    }

}
