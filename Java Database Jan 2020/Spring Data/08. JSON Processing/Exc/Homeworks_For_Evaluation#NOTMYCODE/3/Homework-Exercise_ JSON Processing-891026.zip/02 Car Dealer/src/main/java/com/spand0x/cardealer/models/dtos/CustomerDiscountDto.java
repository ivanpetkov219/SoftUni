package com.spand0x.cardealer.models.dtos;

public class CustomerDiscountDto {
}
