package com.example.demo.models.Enums;

public enum AgeRestriction {
    MINOR,TEEN,ADULT
}
