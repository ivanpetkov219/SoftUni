package Vehicles;

import java.text.DecimalFormat;

public abstract class VehicleImpl implements Vehicle{
    private double fuelQuantity;
    private double consumptionPerKm;


    public VehicleImpl(double fuelQuantity, double consumptionPerKm) {
        this.fuelQuantity = fuelQuantity;
        this.consumptionPerKm = consumptionPerKm;
    }

    public void drive(double distance){
        if(hasEnoughFuelToDrive(distance)){
            reduceFuelQuantity(distance);
            printTravellMessage(distance);
        }else {
            printNeedsRefuelMessage();
        }
    }

    public void refuel(double liters) {
        if(this.getClass().getSimpleName().equals("Truck")) {
            this.fuelQuantity += liters * 0.95;
        }else {
            this.fuelQuantity += liters;
        }
    }

    private boolean hasEnoughFuelToDrive (double distance){
        return  this.getFuelQuantity() >= this.consumptionPerKm * distance;
    }

    private void reduceFuelQuantity(double distance){
        this.setFuelQuantity(this.getFuelQuantity() - (this.getConsumptionPerKm() * distance));
    }

    private void printTravellMessage(double distance) {

        DecimalFormat output = new DecimalFormat("#.##");
        System.out.println(String.format("%s travelled %s km",this.getClass().getSimpleName(), output.format(distance)));
    }

    private void printNeedsRefuelMessage(){
        System.out.println(String.format("%s needs refueling", this.getClass().getSimpleName()));
    }

    protected double getFuelQuantity(){
        return this.fuelQuantity;
    }

    private void setFuelQuantity(double fuelQuantity) {
        this.fuelQuantity = fuelQuantity;
    }

    private double getConsumptionPerKm() {
        return this.consumptionPerKm;
    }
}
