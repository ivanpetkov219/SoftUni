package com.example.advanced_querying_hw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvancedQueryingHwApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdvancedQueryingHwApplication.class, args);
    }

}
