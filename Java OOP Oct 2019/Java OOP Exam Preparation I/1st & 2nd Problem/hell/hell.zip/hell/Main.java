package hell;

import hell.entities.HeroImpl;
import hell.entities.items.Wizard;

public class Main {
    public static void main(String[] args) {


    }
}