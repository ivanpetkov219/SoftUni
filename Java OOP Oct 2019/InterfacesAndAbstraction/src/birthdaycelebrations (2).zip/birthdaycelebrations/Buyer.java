package birthdaycelebrations;

public interface Buyer {
    void buyFood();
    int getFood();
}
