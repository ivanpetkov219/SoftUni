package foodshortage;

public interface Identifiable {
    String getId();
}
