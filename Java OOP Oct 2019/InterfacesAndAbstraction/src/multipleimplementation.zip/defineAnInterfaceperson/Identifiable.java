package defineAnInterfaceperson;

public interface Identifiable {
    String getId();
}
