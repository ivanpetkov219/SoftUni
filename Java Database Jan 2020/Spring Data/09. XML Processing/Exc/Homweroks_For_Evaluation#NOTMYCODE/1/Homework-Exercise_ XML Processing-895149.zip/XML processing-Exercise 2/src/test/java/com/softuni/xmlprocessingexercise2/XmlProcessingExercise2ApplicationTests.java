package com.softuni.xmlprocessingexercise2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlProcessingExercise2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
