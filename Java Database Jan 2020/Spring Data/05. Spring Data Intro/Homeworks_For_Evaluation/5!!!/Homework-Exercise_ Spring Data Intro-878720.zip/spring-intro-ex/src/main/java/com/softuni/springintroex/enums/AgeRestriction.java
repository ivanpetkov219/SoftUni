package com.softuni.springintroex.enums;

public enum AgeRestriction {

    MINOR, TEEN, ADULT;
}
