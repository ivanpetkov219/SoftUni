package trafficlight;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW,
}
