package spring.map.spingautomapping.domain.entities;

public enum Role {
    ADMIN, USER
}
