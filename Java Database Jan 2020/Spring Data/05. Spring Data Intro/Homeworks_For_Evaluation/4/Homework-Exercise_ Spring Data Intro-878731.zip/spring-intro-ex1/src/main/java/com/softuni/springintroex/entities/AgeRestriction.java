package com.softuni.springintroex.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
