package com.springdataintro.springintroex.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
