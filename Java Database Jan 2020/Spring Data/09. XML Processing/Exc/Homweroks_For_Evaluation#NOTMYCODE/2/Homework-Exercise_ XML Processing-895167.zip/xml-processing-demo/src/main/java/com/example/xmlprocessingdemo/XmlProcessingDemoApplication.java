package com.example.xmlprocessingdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlProcessingDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(XmlProcessingDemoApplication.class, args);
    }

}
