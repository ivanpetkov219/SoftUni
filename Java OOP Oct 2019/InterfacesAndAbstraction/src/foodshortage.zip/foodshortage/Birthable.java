package foodshortage;

public interface Birthable {
    String getBirthDate();
}
