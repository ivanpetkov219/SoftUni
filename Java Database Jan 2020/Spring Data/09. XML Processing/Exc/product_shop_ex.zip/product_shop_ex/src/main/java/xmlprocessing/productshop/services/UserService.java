package xmlprocessing.productshop.services;

public interface UserService  {
}
