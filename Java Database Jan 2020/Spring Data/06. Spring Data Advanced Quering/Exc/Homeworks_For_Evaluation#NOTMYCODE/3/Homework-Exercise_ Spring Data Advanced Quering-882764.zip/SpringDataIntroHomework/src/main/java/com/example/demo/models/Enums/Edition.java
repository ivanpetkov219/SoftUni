package com.example.demo.models.Enums;

public enum Edition {
    NORMAL,PROMO,GOLD
}
