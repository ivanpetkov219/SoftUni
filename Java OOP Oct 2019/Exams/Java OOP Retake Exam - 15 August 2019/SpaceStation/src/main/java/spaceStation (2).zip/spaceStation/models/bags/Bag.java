package spaceStation.models.bags;

import models.bags.Backpack;

import java.util.List;

public interface Bag {
    List<Backpack> getItems();
}
