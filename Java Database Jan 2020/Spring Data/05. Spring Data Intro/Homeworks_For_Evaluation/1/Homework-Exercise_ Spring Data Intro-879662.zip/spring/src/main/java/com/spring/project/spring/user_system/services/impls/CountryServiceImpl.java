package com.spring.project.spring.user_system.services.impls;

import com.spring.project.spring.user_system.services.CountryService;
import org.springframework.stereotype.Service;

@Service
public class CountryServiceImpl implements CountryService {
}
