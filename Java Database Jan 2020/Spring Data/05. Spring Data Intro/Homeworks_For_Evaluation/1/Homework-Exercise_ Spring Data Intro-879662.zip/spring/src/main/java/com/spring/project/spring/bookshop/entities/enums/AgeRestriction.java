package com.spring.project.spring.bookshop.entities.enums;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
