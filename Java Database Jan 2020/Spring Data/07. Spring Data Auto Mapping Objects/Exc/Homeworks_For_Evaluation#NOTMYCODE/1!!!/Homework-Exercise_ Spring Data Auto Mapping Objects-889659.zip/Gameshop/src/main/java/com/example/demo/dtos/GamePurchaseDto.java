package com.example.demo.dtos;

import java.math.BigDecimal;

public class GamePurchaseDto {
    private String title;
    private BigDecimal price;
}
