package com.example.spingautomappingex.domain.entities;

public enum Role {
    ADMIN, USER
}
