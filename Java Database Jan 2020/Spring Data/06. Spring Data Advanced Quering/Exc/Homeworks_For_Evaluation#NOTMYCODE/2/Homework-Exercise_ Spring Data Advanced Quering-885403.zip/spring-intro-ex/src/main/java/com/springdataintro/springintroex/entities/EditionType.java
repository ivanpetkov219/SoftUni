package com.springdataintro.springintroex.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
