package com.spring.project.spring.user_system.services.impls;

import com.spring.project.spring.user_system.services.TownService;
import org.springframework.stereotype.Service;

@Service
public class TownServiceImpl implements TownService {
}
