package com.cardealer.cardealer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardealerApplicationTests {

    @Test
    void contextLoads() {
    }

}
