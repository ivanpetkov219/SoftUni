package com.spring.project.spring.user_system.services.impls;

import com.spring.project.spring.user_system.services.AlbumService;
import org.springframework.stereotype.Service;

@Service
public class AlbumServiceImpl implements AlbumService {

}
