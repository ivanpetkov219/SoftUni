package com.springdataintro.springintroex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIntroExApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringIntroExApplication.class, args);
    }

}
