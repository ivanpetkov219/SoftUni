package com.example.sprintdataintroex.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
