1. DBrefresh - will create or restore table minions_db .
2. CreateUsp_get_older - will create stored procedure needed for the last problem.
3. set your password for database and uncomment only! method you want to test.
4. Dont forget to refresh database usin FBrefresh befor runing any test.
Tanks!
Have a nice day ;)