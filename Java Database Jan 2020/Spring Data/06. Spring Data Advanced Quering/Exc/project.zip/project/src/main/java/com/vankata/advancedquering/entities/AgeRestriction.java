package com.vankata.advancedquering.entities;


public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
