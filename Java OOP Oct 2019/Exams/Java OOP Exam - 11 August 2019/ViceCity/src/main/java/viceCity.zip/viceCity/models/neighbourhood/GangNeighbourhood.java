package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;

import java.util.Collection;

public class GangNeighbourhood implements Neighbourhood { //TODO

    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {
        //SHOOTS BULLETS, RELOADS IF EMPTY AND CONTINUES UNTIL NO BULLETS. THEN TAKES THE NEXT GUN
        //STOPS WHEN GUNREPO IS EMPTY OR ALL CIVILS ARE DEAD
        //



    }


}
