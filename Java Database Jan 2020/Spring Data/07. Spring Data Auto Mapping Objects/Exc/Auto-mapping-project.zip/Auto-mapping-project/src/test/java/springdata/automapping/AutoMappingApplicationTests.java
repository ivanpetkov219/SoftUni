package springdata.automapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoMappingApplicationTests {

    @Test
    void contextLoads() {
    }

}
