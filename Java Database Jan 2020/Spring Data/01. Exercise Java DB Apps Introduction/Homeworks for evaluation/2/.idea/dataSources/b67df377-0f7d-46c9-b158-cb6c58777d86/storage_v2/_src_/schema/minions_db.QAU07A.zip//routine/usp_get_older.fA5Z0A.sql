create
    definer = root@localhost procedure usp_get_older(IN minion_id int)
BEGIN
	update minions
	set age = age + 1
	where id = minion_id;
END;

