package springdata.automapping.services;


public interface OrderService {
}
