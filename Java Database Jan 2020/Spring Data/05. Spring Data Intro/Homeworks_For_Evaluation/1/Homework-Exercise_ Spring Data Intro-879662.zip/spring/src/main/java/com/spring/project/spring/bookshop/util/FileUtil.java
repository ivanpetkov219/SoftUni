package com.spring.project.spring.bookshop.util;

public interface FileUtil {
    String[] readFile(String path);
}
