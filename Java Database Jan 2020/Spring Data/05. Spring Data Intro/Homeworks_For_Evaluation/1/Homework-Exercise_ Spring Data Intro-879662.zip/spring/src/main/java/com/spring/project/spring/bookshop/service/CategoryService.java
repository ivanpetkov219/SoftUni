package com.spring.project.spring.bookshop.service;

import org.springframework.stereotype.Service;

@Service("categoryService")
public interface CategoryService {
    void seedCategory();
}
