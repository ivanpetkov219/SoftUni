package com.spring.project.spring.user_system.services;

import org.springframework.stereotype.Service;

@Service("countryService")
public interface CountryService {
}
