package com.softuni.xmlparsingexerciseone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlParsingExerciseOneApplication {

    public static void main(String[] args) {
        SpringApplication.run(XmlParsingExerciseOneApplication.class, args);
    }

}
