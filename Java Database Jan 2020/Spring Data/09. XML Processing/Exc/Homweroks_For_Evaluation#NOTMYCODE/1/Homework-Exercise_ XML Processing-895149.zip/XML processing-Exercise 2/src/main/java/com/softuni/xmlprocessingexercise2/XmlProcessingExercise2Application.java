package com.softuni.xmlprocessingexercise2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlProcessingExercise2Application {

    public static void main(String[] args) {
        SpringApplication.run(XmlProcessingExercise2Application.class, args);
    }

}
