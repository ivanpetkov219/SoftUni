package com.vankata.advancedquering.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
