package springdata.automapping.models.entities;

public enum AccessRight {
    ADMINISTRATOR, USER;
}
