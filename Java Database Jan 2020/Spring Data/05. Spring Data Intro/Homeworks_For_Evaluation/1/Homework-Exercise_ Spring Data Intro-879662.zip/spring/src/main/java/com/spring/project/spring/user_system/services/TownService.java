package com.spring.project.spring.user_system.services;

import org.springframework.stereotype.Service;

@Service("townService")
public interface TownService {
}
