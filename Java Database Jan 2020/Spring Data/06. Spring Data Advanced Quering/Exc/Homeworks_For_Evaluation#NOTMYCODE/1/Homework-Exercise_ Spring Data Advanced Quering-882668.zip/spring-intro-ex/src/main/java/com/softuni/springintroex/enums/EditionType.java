package com.softuni.springintroex.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD;
}
